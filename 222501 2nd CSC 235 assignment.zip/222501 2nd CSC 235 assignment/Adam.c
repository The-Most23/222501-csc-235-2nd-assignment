#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(){

    char line[100];
    int lenght;
    //Reading user inputs from an external file named Adam.in

    FILE * fpointer = fopen("Adam.in","r");//opening the file 

    //Asking for the number of tests that will be carried out
    printf("How many tests will be carried out? ");
    fgets(line, 100, fpointer);
    printf("\n%s", line);

    
      //checking the lenght of the inputs from the file
      //printing line 2
       fgets(line, 100, fpointer);
       printf("%s", line);
       lenght = strlen(line) - 1;//-1 because of the /n that is always at the end of every line
       //printf("%d",lenght);

       for (int i = 0; i < lenght; i++){

        
        if(line[i] == 'D'){
            //printf("He fell after %d step(s)", i); 
            printf("%d", i);    
                         break;
                          }
      
       else if (line[i] == line[i+1] && line[i+2] == line[i] && line[i] == line[lenght-1] 
                            && line[lenght-2]== line[i] && line[i] == 'U' ){
            //printf("He doesnt fall at all");
            printf("%d",lenght);
            break;
                                                                                            }
       /*else if(line[i] == 'U' ){
            continue;     
                         break;
                          }*/
       else if (line[i] == line[i+1] && line[i+2] == line[i] && line[i] == line[lenght-1] 
                            && line[lenght-2]== line[i] && line[i] == 'D' ){
            //printf("\nHe never rised");
            printf("0");
            break;
                                                                                            }

        else if(line[i] != 'D' && line[i] != 'U'){
            printf("The input should contain only 'U' or 'D' ");
            break;
        } 
            else if (line[i]=='U'){
                if(line[i]=='D'){
                    printf("%d",i);
                    break;
                }
            } 
        else{
            printf("Error");
            break;
        }      

                                       }
                    
    //printing line 3
       fgets(line, 100, fpointer);
       printf("\n%s", line);
       lenght = strlen(line) - 1;//-1 because of the /n that is always at the end of every line
       //printf("%d",lenght);

       for (int i = 0; i < lenght; i++){

        
        if(line[i] == 'D'){
            //printf("He fell after %d step(s)", i); 
            printf("%d", i);    
                         break;
                          }
      
       else if (line[i] == line[i+1] && line[i+2] == line[i] && line[i] == line[lenght-1] 
                            && line[lenght-2]== line[i] && line[i] == 'U' ){
            //printf("He doesnt fall at all");
            printf("%d",lenght);
            break;
                                                                                            }
       /*else if(line[i] == 'U' ){
            continue;     
                         break;
                          }*/
       else if (line[i] == line[i+1] && line[i+2] == line[i] && line[i] == line[lenght-1] 
                            && line[lenght-2]== line[i] && line[i] == 'D' ){
            //printf("\nHe never rised");
            printf("0");
            break;
                                                                                            }

        else if(line[i] != 'D' && line[i] != 'U'){
            printf("The input should contain only 'U' or 'D' ");
            break;
        } 
            else if (line[i]=='U'){
                if(line[i]=='D'){
                    printf("%d",i);
                    break;
                }
            } 
        else{
            printf("Error");
            break;
        }
                                       }

    //printing line 4
       fgets(line, 100, fpointer);
       printf("\n%s", line);
       lenght = strlen(line) - 1;//-1 because of the /n that is always at the end of every line
       //printf("%d",lenght);

       for (int i = 0; i < lenght; i++){

        
        if(line[i] == 'D'){
            //printf("He fell after %d step(s)", i); 
            printf("%d", i);    
                         break;
                          }
      
       else if (line[i] == line[i+1] && line[i+2] == line[i] && line[i] == line[lenght-1] 
                            && line[lenght-2]== line[i] && line[i] == 'U' ){
            //printf("He doesnt fall at all");
            printf("%d",lenght);
            break;
                                                                                            }
       /*else if(line[i] == 'U' ){
            continue;     
                         break;
                          }*/
       else if (line[i] == line[i+1] && line[i+2] == line[i] && line[i] == line[lenght-1] 
                            && line[lenght-2]== line[i] && line[i] == 'D' ){
            //printf("\nHe never rised");
            printf("0");
            break;
                                                                                            }

        else if(line[i] != 'D' && line[i] != 'U'){
            printf("The input should contain only 'U' or 'D' ");
            break;
        } 
            else if (line[i]=='U'){
                if(line[i]=='D'){
                    printf("%d",i);
                    break;
                }
            } 
        else{
            printf("Error");
            break;
        }
                                       }

    //printing line 5
       fgets(line, 100, fpointer);
       printf("\n%s", line);
       lenght = strlen(line) - 1;//-1 because of the /n that is always at the end of every line
       //printf("%d",lenght);

       for (int i = 0; i < lenght; i++){

        
        if(line[i] == 'D'){
            //printf("He fell after %d step(s)", i); 
            printf("%d", i);    
                         break;
                          }
      
       else if (line[i] == line[i+1] && line[i+2] == line[i] && line[i] == line[lenght-1] 
                            && line[lenght-2]== line[i] && line[i] == 'U' ){
            //printf("He doesnt fall at all");
            printf("%d",lenght);
            break;
                                                                                            }
       /*else if(line[i] == 'U' ){
            continue;     
                         break;
                          }*/
       else if (line[i] == line[i+1] && line[i+2] == line[i] && line[i] == line[lenght-1] 
                            && line[lenght-2]== line[i] && line[i] == 'D' ){
            //printf("\nHe never rised");
            printf("0");
            break;
                                                                                            }

        else if(line[i] != 'D' && line[i] != 'U'){
            printf("The input should contain only 'U' or 'D' ");
            break;
        } 
            else if (line[i]=='U'){
                if(line[i]=='D'){
                    printf("%d",i);
                    break;
                }
            } 
        else{
            printf("Error");
            break;
        }
                                       }
    
    fclose(fpointer);
    return 0;

}